// In-memory data store for a simple classroom demonstration.
// Data resets when the server restarts. A database can be added later.
let students = [
  {
    id: 1,
    name: "Aarav Patil",
    email: "aarav@example.com",
    rollNo: "TY001",
    department: "Computer Engineering",
    year: "Third Year"
  },
  {
    id: 2,
    name: "Sana Shaikh",
    email: "sana@example.com",
    rollNo: "TY002",
    department: "Computer Engineering",
    year: "Third Year"
  }
];
let nextId = 3;

exports.listStudents = (req, res) => {
  res.render("index", {
    title: "Student Directory",
    students,
    username: req.session.username
  });
};

exports.showAddForm = (req, res) => {
  res.render("student-form", {
    title: "Add Student",
    heading: "Add New Student",
    student: {},
    errors: [],
    formAction: "/students"
  });
};

exports.createStudent = (req, res) => {
  const student = {
    id: nextId++,
    name: req.body.name.trim(),
    email: req.body.email.trim().toLowerCase(),
    rollNo: req.body.rollNo.trim().toUpperCase(),
    department: req.body.department.trim(),
    year: req.body.year
  };
  students.push(student);
  res.redirect(`/students/${student.id}`);
};

exports.showStudent = (req, res, next) => {
  const student = students.find((item) => item.id === Number(req.params.id));
  if (!student) return res.status(404).render("not-found", { title: "Student Not Found" });
  res.render("student-details", { title: "Student Details", student });
};

exports.showEditForm = (req, res) => {
  const student = students.find((item) => item.id === Number(req.params.id));
  if (!student) return res.status(404).render("not-found", { title: "Student Not Found" });
  res.render("student-form", {
    title: "Edit Student",
    heading: "Edit Student",
    student,
    errors: [],
    formAction: `/students/${student.id}/update`
  });
};

exports.updateStudent = (req, res) => {
  const student = students.find((item) => item.id === Number(req.params.id));
  if (!student) return res.status(404).render("not-found", { title: "Student Not Found" });

  student.name = req.body.name.trim();
  student.email = req.body.email.trim().toLowerCase();
  student.rollNo = req.body.rollNo.trim().toUpperCase();
  student.department = req.body.department.trim();
  student.year = req.body.year;

  res.redirect(`/students/${student.id}`);
};

exports.deleteStudent = (req, res) => {
  const studentId = Number(req.params.id);
  const exists = students.some((item) => item.id === studentId);
  if (!exists) return res.status(404).render("not-found", { title: "Student Not Found" });
  students = students.filter((item) => item.id !== studentId);
  res.redirect("/students");
};
