const express = require("express");
const router = express.Router();
const studentController = require("../controllers/studentController");
const { studentValidationRules, validateStudent } = require("../middleware/validation");

// GET /students - show all students
router.get("/", studentController.listStudents);

// GET /students/new - show add form
router.get("/new", studentController.showAddForm);

// POST /students - validate and create a student
router.post("/", studentValidationRules, validateStudent, studentController.createStudent);

// GET /students/:id - route parameter example
router.get("/:id", studentController.showStudent);

// GET /students/:id/edit - show edit form
router.get("/:id/edit", studentController.showEditForm);

// POST /students/:id/update - validate and update a student
router.post("/:id/update", studentValidationRules, validateStudent, studentController.updateStudent);

// POST /students/:id/delete - delete a student
router.post("/:id/delete", studentController.deleteStudent);

module.exports = router;
