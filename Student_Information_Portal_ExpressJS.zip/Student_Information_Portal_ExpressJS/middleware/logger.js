// Custom middleware: logs the HTTP method, URL and request time.
function requestLogger(req, res, next) {
  console.log(`[CUSTOM LOGGER] ${new Date().toISOString()} ${req.method} ${req.originalUrl}`);
  next();
}

module.exports = { requestLogger };
