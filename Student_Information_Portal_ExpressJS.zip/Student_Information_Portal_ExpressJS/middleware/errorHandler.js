function notFound(req, res, next) {
  res.status(404).render("not-found", { title: "Page Not Found" });
}

// Centralized Express error-handling middleware (four parameters are required).
function errorHandler(err, req, res, next) {
  console.error("[ERROR HANDLER]", err.stack || err);
  res.status(err.status || 500).render("error", {
    title: "Something Went Wrong",
    message: process.env.NODE_ENV === "production"
      ? "An unexpected server error occurred."
      : (err.message || "An unexpected server error occurred.")
  });
}

module.exports = { notFound, errorHandler };
