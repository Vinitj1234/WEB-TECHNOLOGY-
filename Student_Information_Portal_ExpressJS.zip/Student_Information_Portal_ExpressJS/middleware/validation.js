const { body, validationResult } = require("express-validator");

const studentValidationRules = [
  body("name")
    .trim()
    .notEmpty().withMessage("Student name is required.")
    .isLength({ min: 2, max: 50 }).withMessage("Name must contain 2 to 50 characters.")
    .matches(/^[A-Za-z .'-]+$/).withMessage("Name can contain letters, spaces, dots, apostrophes and hyphens only."),
  body("email")
    .trim()
    .notEmpty().withMessage("Email is required.")
    .isEmail().withMessage("Enter a valid email address."),
  body("rollNo")
    .trim()
    .notEmpty().withMessage("Roll number is required.")
    .isLength({ min: 2, max: 15 }).withMessage("Roll number must contain 2 to 15 characters.")
    .matches(/^[A-Za-z0-9-]+$/).withMessage("Roll number can contain letters, numbers and hyphens only."),
  body("department")
    .trim()
    .notEmpty().withMessage("Department is required.")
    .isLength({ min: 2, max: 60 }).withMessage("Department must contain 2 to 60 characters."),
  body("year")
    .isIn(["First Year", "Second Year", "Third Year", "Final Year"])
    .withMessage("Select a valid academic year.")
];

function validateStudent(req, res, next) {
  const result = validationResult(req);
  if (result.isEmpty()) return next();

  const student = {
    name: req.body.name || "",
    email: req.body.email || "",
    rollNo: req.body.rollNo || "",
    department: req.body.department || "",
    year: req.body.year || ""
  };

  const isEdit = req.path.includes("/update");
  const id = req.params.id;
  const formAction = isEdit ? `/students/${id}/update` : "/students";

  return res.status(400).render("student-form", {
    title: isEdit ? "Edit Student" : "Add Student",
    heading: isEdit ? "Edit Student" : "Add New Student",
    student,
    errors: result.array(),
    formAction
  });
}

module.exports = { studentValidationRules, validateStudent };
