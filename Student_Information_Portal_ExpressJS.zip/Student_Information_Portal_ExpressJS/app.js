const express = require("express");
const session = require("express-session");
const path = require("path");
const morgan = require("morgan");

const studentRoutes = require("./routes/studentRoutes");
const { requestLogger } = require("./middleware/logger");
const { requireLogin } = require("./middleware/auth");
const { notFound, errorHandler } = require("./middleware/errorHandler");

const app = express();
const PORT = process.env.PORT || 3000;

// View engine and built-in middleware
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Third-party middleware
app.use(morgan("dev"));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-demo-secret-before-production",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" }
}));

// Custom middleware
app.use(requestLogger);

// Demo login page and handler. For classroom demonstration only.
app.get("/login", (req, res) => {
  if (req.session.loggedIn) return res.redirect("/students");
  res.render("login", { title: "Login", error: null });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  // Demo credentials. Replace with a database and hashed passwords in a real application.
  if (username === "admin" && password === "admin123") {
    req.session.loggedIn = true;
    req.session.username = username;
    return res.redirect("/students");
  }
  return res.status(401).render("login", {
    title: "Login",
    error: "Invalid username or password. Try the demo credentials shown below."
  });
});

app.post("/logout", (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.redirect("/login");
  });
});

app.get("/", (req, res) => {
  res.redirect(req.session.loggedIn ? "/students" : "/login");
});

// Protect the student portal routes with custom authentication middleware.
app.use("/students", requireLogin, studentRoutes);

app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Student Information Portal running at http://localhost:${PORT}`);
});
